﻿using System;
using System.Collections.Generic;

namespace Etimo_Case_Uppgift
{
    class Program
    {
        //Variabler som behöver vara tillgängliga i alla functioner sparas här
        public int inventory = 0;
        string commandInput;

        static void Main(string[] args)
        {
            //Denna variabeln tillåter denna function att komma åt functioner utanför
            var p = new Program();

            //Ser till att programmet kan köras flera gånger
            do
            {
                //Start function för huvud delev av programmet
                p.RunProgram();
            } while (p.commandInput != "exit");

            
        }        

        //Functionen som sköter outputen. Inte Main functionen, men denna function gör det möjligt att lättare komma åt variabler/functioner.
        public void RunProgram()
        {
            //Consolens outputs när functionen körs
            Console.WriteLine("Välkommen till lagersaldo hanteraren");
            Console.WriteLine("Se till att du ger korrekt input");
            Console.WriteLine(@"Skriv 'exit' för att avsluta");

            //Tar en input som är omvandlad till lowercase. La även in functionalitet för uppercase då jag hade problem med .ToLower() först och
            //som extra säkerhet ifall programmet skulle behövas skrivas om i ett språk som inte har en sådan function (lättare att läsa också)
            commandInput = Console.ReadLine().ToLower();
            
            //Städar consolen för användar vänlighet.
            Console.Clear();
            
            InputGiven(commandInput);
        }

        //Hanterar inputen som användaren har givit. Ser till att den är valid och sedan kallar rätt function beroende på vad användaren gav för input. 
        //Returnerar ingenting, men kan skriva information i consolen.
        public void InputGiven(string input)
        {
            //Temporära variabler som bara behövs i denna function eller functioner som blir kallade från denna. 
            List<char> splitInput = new List<char>();
            char firstChar;
            if (input != "")
            {
                splitInput.AddRange(input);
                firstChar = splitInput[0];
                splitInput.RemoveAt(0);
            }
            else
            {
                firstChar = 'z';
            }

            string number = new string(splitInput.ToArray());

            //Sköter hanteringen av inputen efter den har blivit uppdelad ordentligt. 
            if (firstChar == 's' || firstChar == 'S')
            {
                if (int.TryParse(number, out int isParseable) )
                {
                    
                    int num = int.Parse(number);
                    if (inventory >= num)
                    {
                        if (num <= 0)
                        {
                            Console.WriteLine("Negativa nummer är inte tillåtna");
                        }
                        else
                        {
                            RemoveInventory(num);
                        }
                    }
                    else
                    {
                        Console.WriteLine("För lite lagersaldo. Inga ändringar gjorda till saldot.");
                    }
                }
                else
                {
                    Console.WriteLine("Se till att du ger korrekt input");
                }
            }
            else if (firstChar == 'i' || firstChar == 'I')
            {
                if (int.TryParse(number, out int isParseable))
                {
                    int num = int.Parse(number);
                    if (num < 0)
                    {
                        Console.WriteLine("Negativa nummer är inte tillåtna");
                    }
                    else
                    {
                        AddInventory(num);
                    }
                }
                else
                {
                    Console.WriteLine("Se till att du ger korrekt input");
                }
            }
            else if (number.Length == 0 && firstChar == 'l' || firstChar == 'L')//La in en extra koll här för att öka användar vänligheten. 
            {                                                                   //Om man skriver ett ord/mening som börjar med L så kommer man inte få en return av lagersaldot. 
                ShowInventory();
            }
            else if (commandInput == "exit")
            {
                Console.WriteLine("Tack för nu!");
            }
            else
            {
                Console.WriteLine("Se till att du ger korrekt input");
            }
        }

        //Lägger till saker i inventory (lagersaldot). Skriver även ut det nya värdet på inventory (lagersaldot) i consolen
        public void AddInventory(int sumToAdd)
        {
            inventory = inventory + sumToAdd;
            Console.WriteLine("Nytt lagersaldo är  " + inventory + ".");
        }

        //tar bort saker från inventory (lagersaldot). Skriver även ut det nya värdet på inventory (lagersaldot) i consolen
        public void RemoveInventory(int sumToRemove)
        {
            inventory = inventory - sumToRemove;
            Console.WriteLine("Nytt lagersaldo är  " + inventory + ".");
        }

        //Visar hur mycket som finns i inventory (lagersaldot)
        public void ShowInventory()
        {
            Console.WriteLine("Ditt lagersaldo är " + inventory + ".");
        }
    }
}
